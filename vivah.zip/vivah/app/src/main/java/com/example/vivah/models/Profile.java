package com.example.vivah.models;



import java.util.ArrayList;

public class Profile {
    public String firstName,lastName,callWord,gender,caste,subCast,gotra,maritalStatus,height,weight,diet,highestQualification
            ,jobDescription,income,fatherName,fatherOccupation,motherName,motherOccupation
            ,state,district,fullAddress,liveWithFamily,mobileNo,password,motherTongue,createBy,whereFamilyLive,token;
    public int dd,mm,yyyy;
    public ArrayList<FamilyMember> familyMember;
    public String profileImage;
    public ArrayList<String> moreImages;
    public ArrayList<String>  hobbies;


}

