package com.example.vivah.adapters;


import android.net.Uri;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.vivah.databinding.CostomSingleImageBinding;


import java.util.ArrayList;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ViewHolder> {
    private final ArrayList<Uri> uriArrayList;

    public ImageAdapter(ArrayList<Uri> uriArrayList) {
        this.uriArrayList = uriArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        CostomSingleImageBinding costomSingleImageBinding = CostomSingleImageBinding.inflate(
                LayoutInflater.from(parent.getContext()),
                parent,
                false
        );
        return  new ViewHolder(costomSingleImageBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageAdapter.ViewHolder holder, int position) {
        holder.binding.image.setImageURI(uriArrayList.get(position));
    }

    @Override
    public int getItemCount() {
        return uriArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CostomSingleImageBinding binding;
        public ViewHolder(CostomSingleImageBinding costomSingleImageBinding) {
            super(costomSingleImageBinding.getRoot());
            binding = costomSingleImageBinding;
        }


    }
}
