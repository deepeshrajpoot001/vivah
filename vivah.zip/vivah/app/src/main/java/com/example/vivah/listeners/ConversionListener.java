package com.example.vivah.listeners;

import com.example.vivah.models.User;

public interface ConversionListener {
    void onConversionClicked(User user);
}
