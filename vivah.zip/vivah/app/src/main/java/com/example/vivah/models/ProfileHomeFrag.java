package com.example.vivah.models;

import android.net.Uri;

public class ProfileHomeFrag {
    public String name,age,profession,birthOfPlace,id;
    public Uri profileImage;
}
