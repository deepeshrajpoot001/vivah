package com.example.vivah.activities;

import static com.example.vivah.activities.CreateProfile1.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.example.vivah.R;
import com.example.vivah.databinding.ActivityCreateProfile4Binding;
import com.example.vivah.utilities.Constants;
import com.google.android.material.chip.Chip;


public class CreateProfile4 extends AppCompatActivity {
    ActivityCreateProfile4Binding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateProfile4Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        profile.liveWithFamily = "YES";
        binding.whereFamilyLive.setText("live with family");


        String[] motherTongue = getResources().getStringArray(R.array.languages);




        binding.liveWithFamilySelection.setOnCheckedStateChangeListener((group, checkedIds) -> {

            Chip chip = findViewById(group.getCheckedChipId());

            String str;

            if(chip!=null){
                str = chip.getText().toString();
            }else{
                str="";
            }

            Toast.makeText(getApplicationContext(), str,Toast.LENGTH_SHORT).show();


            switch (str) {

                case "":
                    profile.liveWithFamily = "";
                    break;
                case "NO":
                    profile.liveWithFamily = "NO";
                    binding.whereFamilyLive.setText("");
                    binding.whereFamilyLiveLayout.setVisibility(View.VISIBLE);
                    binding.whereFamilyLive.setVisibility(View.VISIBLE);
                    break;
                case "YES":
                    profile.liveWithFamily = "YES";
                    binding.whereFamilyLiveLayout.setVisibility(View.GONE);
                    binding.whereFamilyLive.setVisibility(View.GONE);
                    String address = "live with family";
                    binding.whereFamilyLive.setText(address);

                    break;
            }


        });

        ArrayAdapter<String> adapterMaritalStatus = new ArrayAdapter<>(getApplicationContext(),R.layout.drop_down_item, Constants.maritalStatus);
        ArrayAdapter<String> adapterDiet = new ArrayAdapter<>(getApplicationContext(),R.layout.drop_down_item, Constants.diet);
        ArrayAdapter<String> adapterHeight = new ArrayAdapter<>(getApplicationContext(),R.layout.drop_down_item, Constants.height);
        ArrayAdapter<String>  adapterWeight = new ArrayAdapter<>(getApplicationContext(),R.layout.drop_down_item, Constants.weight);
        ArrayAdapter<String>   adapterMotherTongue = new ArrayAdapter<>(getApplicationContext(),R.layout.drop_down_item, motherTongue);

        binding.maritalStatus.setAdapter(adapterMaritalStatus);
        binding.diet.setAdapter(adapterDiet);
        binding.height.setAdapter(adapterHeight);
        binding.weight.setAdapter(adapterWeight);
        binding.motherTongue.setAdapter(adapterMotherTongue);

        binding.maritalStatus.setKeyListener(null);
        binding.diet.setKeyListener(null);
        binding.height.setKeyListener(null);
        binding.weight.setKeyListener(null);
        binding.motherTongue.setKeyListener(null);

        binding.backButton.setOnClickListener(v-> onBackPressed());

        binding.continueButton.setOnClickListener(v -> {
            if(isValidDetail()){
                profile.maritalStatus = binding.maritalStatus.getText().toString();
                profile.diet= binding.diet.getText().toString();
                profile.height = binding.height.getText().toString();
                profile.weight = binding.weight.getText().toString();
                profile.motherTongue = binding.motherTongue.getText().toString();
                profile.whereFamilyLive = binding.whereFamilyLive.getText().toString();
                startActivity(new Intent(getApplicationContext(),CreateProfile5.class));
            }
        });









    }
    private void showMessage(String message){
        Toast.makeText(getApplicationContext(),message, Toast.LENGTH_LONG).show();

    }

    public boolean isValidDetail() {

        if (binding.maritalStatus.getText().toString().trim().isEmpty()) {
            showMessage("enter marital status");
            return false;
        } else if (binding.diet.getText().toString().trim().isEmpty()) {
            showMessage("enter diet");
            return false;
        } else if (binding.height.getText().toString().trim().isEmpty()) {
            showMessage("enter height");
            return false;
        } else if (binding.weight.getText().toString().trim().isEmpty()) {
            showMessage("enter weight");
            return false;
        } else if (binding.motherTongue.getText().toString().trim().isEmpty()) {
            showMessage("enter mother tongue");
            return false;
        }else if(binding.whereFamilyLive.getText().toString().trim().isEmpty()){
            showMessage("enter where family lives");
            return  false;
        }
        else {
            return true;
        }
    }

}