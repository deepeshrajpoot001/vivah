package com.example.vivah.activities;

import static com.example.vivah.activities.CreateProfile1.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.example.vivah.R;
import com.example.vivah.databinding.ActivityCreateProfile7Binding;
import com.example.vivah.utilities.Constants;
import com.google.android.material.chip.Chip;


import java.util.Objects;

public class CreateProfile7 extends AppCompatActivity {
    ActivityCreateProfile7Binding binding;
    int incomeType; //  1 - monthly    2 - yearly

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateProfile7Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ArrayAdapter<String> adapterIncomeMonthly = new ArrayAdapter<>(getApplicationContext(),R.layout.drop_down_item, Constants.monthlyIncome);
        ArrayAdapter<String> adapterIncomeYearly = new ArrayAdapter<>(getApplicationContext(),R.layout.drop_down_item,Constants.yearlyIncome);

        binding.income.setAdapter(adapterIncomeYearly);
        binding.income.setKeyListener(null);

        binding.incomeSelection.setOnCheckedStateChangeListener((group, checkedIds) -> {
            Chip chip = findViewById(group.getCheckedChipId());

            String str;

            if(chip!=null){
                str = chip.getText().toString();
            }else{
                str="";
            }

            Toast.makeText(getApplicationContext(), str,Toast.LENGTH_SHORT).show();



            switch (str) {

                case "":
                    binding.income.setVisibility(View.INVISIBLE);
                    binding.income.setText("");
                      incomeType = 0;
                    break;
                case "Yearly":
                    binding.income.setAdapter(adapterIncomeYearly);
                    binding.income.setVisibility(View.VISIBLE);
                    binding.income.setText("");
                   incomeType = 2;
                    break;
                case "Monthly":
                    binding.income.setAdapter(adapterIncomeMonthly);
                    binding.income.setVisibility(View.VISIBLE);
                    binding.income.setText("");
                    incomeType = 1;
                    break;
            }
        });



        binding.backButton.setOnClickListener(v-> onBackPressed());

        binding.continueButton.setOnClickListener(v -> {
            if(isValidDetail()){
                profile.highestQualification = binding.highestQualification.getText().toString();
                profile.jobDescription = binding.job.getText().toString();
                profile.income = binding.income.getText().toString();
                Intent intent = new Intent(getApplicationContext(),VerificationActivity.class);
                intent.putExtra("type","setPassword");
                startActivity(intent);
            }
        });




    }


    private void showMessage(String message){
        Toast.makeText(getApplicationContext(),message, Toast.LENGTH_LONG).show();
    }
    public boolean isValidDetail(){
        if(Objects.requireNonNull(binding.highestQualification.getText()).toString().trim().isEmpty()){
            showMessage("enter highest Qualification");
            return  false;
        }else if(Objects.requireNonNull(binding.job.getText()).toString().trim().isEmpty()){
            showMessage("enter jobDescription");
            return false;
        }else if(binding.income.getText().toString().trim().isEmpty()){
            showMessage("enter income carefully");
            return false;
        }else{
            return true;
        }
    }
}