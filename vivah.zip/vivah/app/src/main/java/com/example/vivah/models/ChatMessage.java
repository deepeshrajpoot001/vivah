package com.example.vivah.models;

import java.util.Date;

public class ChatMessage {
    public String senderId,receivedId,message,dateTime;
    public Date dateObject;
    public String conversionId,conversionName,conversionImage;
    public String messageType,image;


}
