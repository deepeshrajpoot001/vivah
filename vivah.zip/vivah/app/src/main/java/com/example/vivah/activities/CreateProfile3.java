package com.example.vivah.activities;

import static com.example.vivah.activities.CreateProfile1.profile;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.example.vivah.R;
import com.example.vivah.databinding.ActivityCreateProfile3Binding;


public class CreateProfile3 extends AppCompatActivity {

    ActivityCreateProfile3Binding binding;
    private String[] district;
    private String[] state;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateProfile3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        profile.fullAddress="";
        profile.state="";
        profile.district="";

        binding.backButton.setOnClickListener(v-> onBackPressed());


         state = getResources().getStringArray(R.array.array_indian_states);

         ArrayAdapter<String> adapterState = new ArrayAdapter<>(getApplicationContext(),R.layout.drop_down_item,state);
         binding.state.setAdapter(adapterState);
         binding.state.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                 profile.state = binding.state.getText().toString();
                 updateDistrict(getResources().getStringArray(findResourcesOfState(profile.state)));
                 binding.districtLayout.setVisibility(View.VISIBLE);
             }
         });



    }

    public void updateDistrict(String[] district){
         this.district = district;
        ArrayAdapter<String> adapterDistrict = new ArrayAdapter<>(getApplicationContext(),R.layout.drop_down_item,district);
        binding.district.setText("");
        binding.district.setAdapter(adapterDistrict);

        binding.district.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                profile.district = binding.district.getText().toString();
            }
        });

        binding.continueButton.setOnClickListener(v -> {
            if(isValidDetail()){
                if(!binding.fullAddressEditText.getText().toString().trim().isEmpty()){
                    profile.fullAddress = binding.fullAddressEditText.getText().toString();
                }else{
                    profile.fullAddress = "Empty";
                }
                startActivity(new Intent(getApplicationContext(),CreateProfile4.class));
            }
            else{
                Toast.makeText(getApplicationContext(), "fill valid detail", Toast.LENGTH_SHORT).show();
            }


        });


    }

    public boolean isValidDetail(){
        if(binding.state.getText().toString().trim().isEmpty()){
            return false;
        }else if(binding.district.getText().toString().trim().isEmpty()){
            return  false;
        }

        profile.state = binding.state.getText().toString();
        profile.district = binding.district.getText().toString();

        for(int i=0;i<state.length;i++){
                for(int j=0;j<district.length;j++){
                    if(profile.state.equals(state[i])&&profile.district.equals(district[j])){
                        return true;
                    }
                }
        }
        return false;

    }

    public int findResourcesOfState(String state){
        state = state.toLowerCase();
        state = state.replace(' ','_');
        state = "array_"+state+"_districts";

        return getApplicationContext().getResources().getIdentifier(state,"array",getPackageName());
    }





}