package com.example.vivah.models;

import java.util.Date;

public class Inbox {
    public String senderId,receiverId,dateTime;
    public Date dateObject;
    public String inboxId,inboxName,inboxImage,inboxAge,inboxProfession,inboxPlaceOfBirth;
    public String status,docId;

}
