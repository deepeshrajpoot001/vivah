package com.example.vivah.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.example.vivah.R;
import com.example.vivah.adapters.profileHomeFragAdapter;
import com.example.vivah.databinding.ActivitySearchBinding;
import com.example.vivah.models.ProfileHomeFrag;
import com.example.vivah.utilities.Constants;
import com.example.vivah.utilities.PreferenceManager;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.storage.FirebaseStorage;

import java.time.Year;
import java.util.ArrayList;
import java.util.List;

import kotlin.reflect.jvm.internal.impl.descriptors.Visibilities;

public class SearchActivity extends AppCompatActivity {
    private ActivitySearchBinding binding;
    private PreferenceManager preferenceManager;
    private FirebaseStorage firebaseStorage;
    private List<ProfileHomeFrag> profileHomeFrags;
    private com.example.vivah.adapters.profileHomeFragAdapter profileHomeFragAdapter;
    private int i,size;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySearchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        preferenceManager = new PreferenceManager(getApplicationContext());
        firebaseStorage = FirebaseStorage.getInstance();
        profileHomeFrags = new ArrayList<>();
        i=0;

        binding.refreshLayoutHome.setOnRefreshListener(this::getUser);
        getUser();
        setListener();

        profileHomeFragAdapter = new profileHomeFragAdapter(profileHomeFrags,SearchActivity.this);
        binding.profileShowRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        binding.profileShowRecyclerView.setAdapter(profileHomeFragAdapter);

    }

    private void setListener(){


    }

    private void getUser(){
        binding.refreshLayoutHome.setRefreshing(true);
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_USER)
                .get()
                .addOnCompleteListener(task -> {
                    binding.refreshLayoutHome.setRefreshing(false);
                    String currentUserId = preferenceManager.getString(Constants.KEY_USER_ID);
                    if(task.isSuccessful() && task.getResult() != null){
                        size = task.getResult().size();
                        profileHomeFrags.clear();
                        for(QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()){
                            if(currentUserId.equals(queryDocumentSnapshot.getId())){
                                continue;
                            }

                            ProfileHomeFrag profileHomeFrag = new ProfileHomeFrag();
                            profileHomeFrag.name = queryDocumentSnapshot.getString(Constants.KEY_NAME);
                            profileHomeFrag.age = String.valueOf(Year.now().getValue() - Integer.parseInt(String.valueOf(queryDocumentSnapshot.get(Constants.KEY_YEAR_OF_DOB))));
                            profileHomeFrag.profession = queryDocumentSnapshot.getString(Constants.KEY_JOB_DESCRIPTION);
                            profileHomeFrag.birthOfPlace = queryDocumentSnapshot.getString(Constants.KEY_DISTRICT)+","+queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            profileHomeFrag.id= queryDocumentSnapshot.getId();
                            String profileImageUri = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_IMAGE);
                            profileHomeFrag.profileImage = Uri.parse(profileImageUri);

                            profileHomeFrags.add(profileHomeFrag);
                            if(profileHomeFrags.size()>0){
                                profileHomeFragAdapter.notifyDataSetChanged();
                                binding.profileShowRecyclerView.setVisibility(View.VISIBLE);
                                binding.textErrorMessage.setVisibility(View.INVISIBLE);
                            }else{
                                showErrorMessage("11");
                            }
                        }



                    }else{
                        showErrorMessage("2");
                    }
                });
    }


    private void showErrorMessage(String str){
        binding.textErrorMessage.setText(String.format("%s","No user available"+str));
        binding.textErrorMessage.setVisibility(View.VISIBLE);
    }



}