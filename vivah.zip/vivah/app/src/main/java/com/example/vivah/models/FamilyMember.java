package com.example.vivah.models;

public class FamilyMember {
    public String name,relation,occupation;

    public FamilyMember(){

    }

    public FamilyMember(String name, String relation, String occupation) {
        this.name = name;
        this.relation = relation;
        this.occupation = occupation;
    }


}

