package com.example.vivah.activities;

import static com.example.vivah.activities.CreateProfile1.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Toast;

import com.example.vivah.databinding.ActivityCreateProfile5Binding;


public class CreateProfile5 extends AppCompatActivity {

    ActivityCreateProfile5Binding  binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding =  ActivityCreateProfile5Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());



        binding.backButton.setOnClickListener(v-> onBackPressed());



        binding.caste.setText("OBC");
        binding.caste.setKeyListener(null);
        binding.subCaste.setText("Lodhi-Rajpoot");
        binding.subCaste.setKeyListener(null);

        binding.finishButton.setOnClickListener(v -> {
            if(isValidDetail()){
                loading(true);
                profile.caste = binding.caste.getText().toString();
                profile.subCast = binding.subCaste.getText().toString();
                profile.gotra = binding.gotra.getText().toString();
                profile.fatherName = binding.fatherName.getText().toString();
                profile.fatherOccupation = binding.fatherOccupation.getText().toString();
                profile.motherName = binding.motherName.getText().toString();
                profile.motherOccupation = binding.motherOccupation.getText().toString();
                Intent intent = new Intent(getApplicationContext(), CreateProfile7.class);
                startActivity(intent);
                loading(false);
            }
        });

    }

    private void loading(Boolean isLoading){
        if(isLoading){
            binding.finishButton.setVisibility(View.INVISIBLE);
            binding.progressBar.setVisibility(View.VISIBLE);
        }else{
            binding.progressBar.setVisibility(View.INVISIBLE);
            binding.finishButton.setVisibility(View.VISIBLE);
        }
    }


    private void showMessage(String message){
        Toast.makeText(getApplicationContext(),message, Toast.LENGTH_LONG).show();

    }
    private boolean isValidDetail(){
        if(binding.caste.getText().toString().trim().isEmpty()){
            showMessage("enter caste");
            return false;
        }else if(binding.subCaste.getText().toString().trim().isEmpty()){
            showMessage("enter subCaste");
            return false;
        }else if(binding.gotra.getText().toString().trim().isEmpty()){
            showMessage("enter gotra");
            return false;
        }else if(binding.fatherName.getText().toString().trim().isEmpty()){
            showMessage("enter father name");
              return false;
        }else if(binding.fatherOccupation.getText().toString().trim().isEmpty()){
            showMessage("enter father occupation");
            return false;
        }else if(binding.motherName.getText().toString().trim().isEmpty()){
            showMessage("enter mother name");
            return false;
        }else if(binding.motherOccupation.getText().toString().trim().isEmpty()){
            showMessage("enter mother occupation");
            return false;
        }else{
            return true;
        }


    }





}