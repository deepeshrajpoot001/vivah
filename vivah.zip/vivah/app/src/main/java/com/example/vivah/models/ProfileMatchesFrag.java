package com.example.vivah.models;

import android.net.Uri;

public class ProfileMatchesFrag {
    public String name,age,height,profession,language,subCaste,placeOfBirth,id,aboutMe;
    public Uri profileImage;
}
