package com.example.vivah.models;

import java.io.Serializable;

public class User implements Serializable {
    public String name,image,mobNo, email,token,id;
}
