package com.example.vivah.fragment;

import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.vivah.adapters.profileMatchesFragmentAdapter;
import com.example.vivah.databinding.FragmentMatchesBinding;


import com.example.vivah.models.ProfileMatchesFrag;
import com.example.vivah.utilities.Constants;
import com.example.vivah.utilities.PreferenceManager;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.storage.FirebaseStorage;


import java.time.Year;
import java.util.ArrayList;
import java.util.List;


public class MatchesFragment extends Fragment {


    public MatchesFragment() {
        // Required empty public constructor
    }
    private FragmentMatchesBinding binding;


    private PreferenceManager preferenceManager;
    private FirebaseStorage firebaseStorage;
    private List<ProfileMatchesFrag> profileMatchesFrags;
    private profileMatchesFragmentAdapter profileMatchesFragmentAdapter;



    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentMatchesBinding.inflate(inflater,container,false);
        View view = binding.getRoot();
        preferenceManager = new PreferenceManager(container.getContext());
        firebaseStorage = FirebaseStorage.getInstance();
        profileMatchesFrags = new ArrayList<>();

        setUpViewPager();
        getUser();



        return view;


    }

    private void setUpViewPager(){
        binding.profileViewPager.setClipToPadding(false);
        binding.profileViewPager.setClipChildren(false);
        binding.profileViewPager.setOffscreenPageLimit(3);
        binding.profileViewPager.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);
        CompositePageTransformer compositePageTransformer = new CompositePageTransformer();
        compositePageTransformer.addTransformer(new MarginPageTransformer(10));
        compositePageTransformer.addTransformer((page, position) -> {
            float r = 1- Math.abs(position);
            page.setScaleY(0.85f+r*0.15f);
        });
        binding.profileViewPager.setPageTransformer(compositePageTransformer);

        profileMatchesFragmentAdapter = new profileMatchesFragmentAdapter(profileMatchesFrags,getActivity());
        binding.profileViewPager.setAdapter(profileMatchesFragmentAdapter);

    }



    private void getUser(){
        loading(true);
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_USER)
                .get()
                .addOnCompleteListener(task -> {
                    loading(false);
                    String currentUserId = preferenceManager.getString(Constants.KEY_USER_ID);
                    if(task.isSuccessful() && task.getResult() != null){

                        for(QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()){
                            if(currentUserId.equals(queryDocumentSnapshot.getId())){
                                continue;
                            }
                            ProfileMatchesFrag profileMatchesFrag = new ProfileMatchesFrag();
                            profileMatchesFrag.name = queryDocumentSnapshot.getString(Constants.KEY_NAME);
                            profileMatchesFrag.age=  String.valueOf(Year.now().getValue() - Integer.parseInt(String.valueOf(queryDocumentSnapshot.get(Constants.KEY_YEAR_OF_DOB))));
                            profileMatchesFrag.height = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT);
                            profileMatchesFrag.profession = queryDocumentSnapshot.getString(Constants.KEY_JOB_DESCRIPTION);
                            profileMatchesFrag.language = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_TONGUE);
                            profileMatchesFrag.subCaste = queryDocumentSnapshot.getString(Constants.KEY_SUB_CASTE);
                            profileMatchesFrag.placeOfBirth = queryDocumentSnapshot.getString(Constants.KEY_DISTRICT)+","+queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            profileMatchesFrag.id= queryDocumentSnapshot.getId();
                            String profileImageUri = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_IMAGE);
                            profileMatchesFrag.profileImage = Uri.parse(profileImageUri);
                            profileMatchesFrag.aboutMe = queryDocumentSnapshot.getString(Constants.KEY_ABOUT_YOURSELF);

                            profileMatchesFrags.add(profileMatchesFrag);

                            if(profileMatchesFrags.size()>0){
                                profileMatchesFragmentAdapter.notifyDataSetChanged();
                                binding.profileViewPager.setVisibility(View.VISIBLE);
                                binding.textErrorMessage.setVisibility(View.INVISIBLE);
                            }else{
                                showErrorMessage("1");
                            }


                        }



                    }else{
                        showErrorMessage("2");
                    }
                });
    }

    private void showErrorMessage(String str){
        binding.textErrorMessage.setText(String.format("%s","No user available"+str));
        binding.textErrorMessage.setVisibility(View.VISIBLE);
    }

    private void loading (Boolean isLoading){
        if(isLoading){
            binding.progressBar.setVisibility(View.VISIBLE);
        }else{
            binding.progressBar.setVisibility(View.INVISIBLE);
        }
    }


}